/* App entry */

const App = () => {
  const [active, setActive] = React.useState('home');
  const [beginner, setBeginner] = React.useState(true);
  const [surveyOpen, setSurveyOpen] = React.useState(false);
  const [hasResult, setHasResult] = React.useState(true);
  const [whyKey, setWhyKey] = React.useState(null);

  const [tourActive, setTourActive] = React.useState(false);
  const [tourStep, setTourStep] = React.useState(0);

  // First-visit auto-tour
  React.useEffect(() => {
    const seen = localStorage.getItem('tu_tour_v1');
    if (!seen) {
      const t = setTimeout(() => setTourActive(true), 600);
      return () => clearTimeout(t);
    }
  }, []);

  const startTour = () => { setTourStep(0); setTourActive(true); };
  const nextTour = () => {
    if (tourStep < TOUR_STEPS.length - 1) setTourStep(tourStep + 1);
    else { setTourActive(false); localStorage.setItem('tu_tour_v1', '1'); }
  };
  const skipTour = () => { setTourActive(false); localStorage.setItem('tu_tour_v1', '1'); };

  // Close why-pop on outside click
  React.useEffect(() => {
    const handle = (e) => {
      if (!e.target.closest('.why-btn') && !e.target.closest('.why-pop')) setWhyKey(null);
    };
    document.addEventListener('click', handle);
    return () => document.removeEventListener('click', handle);
  }, []);

  return (
    <div className={`app ${beginner ? 'beginner' : 'pro'}`}>
      <Sidebar
        active={active} setActive={setActive}
        beginner={beginner} setBeginner={setBeginner}
        onStartTour={startTour}
        onOpenSurvey={() => setSurveyOpen(true)}
      />

      <main className="main">
        <header className="header">
          <div>
            <div className="header-title">대시보드</div>
            <div className="header-date">2026년 5월 5일 화요일 · 장 마감 14:32</div>
          </div>
          <div className="search">
            <span className="search-icon"><Icon name="search" size={15}/></span>
            <input placeholder="종목명, 티커, 키워드 검색"/>
            <span className="search-kbd">⌘K</span>
          </div>
          <button className="header-btn" title="알림">
            <Icon name="bell" size={17}/>
            <span className="badge"></span>
          </button>
          <button className="header-btn" title="설정">
            <Icon name="settings" size={17}/>
          </button>
          <div className="user-chip">
            <div className="user-avatar">민</div>
            <span className="user-name">민지</span>
          </div>
        </header>

        <div className="content">
          <IndicatorsRow beginner={beginner}/>
          <ChartCard beginner={beginner} whyKey={whyKey} setWhyKey={setWhyKey}/>
          <NewsCard beginner={beginner}/>
          <WatchlistCard beginner={beginner}/>
          <PropensityCard beginner={beginner} hasResult={hasResult}
            openSurvey={() => setSurveyOpen(true)}
            whyKey={whyKey} setWhyKey={setWhyKey}/>
          <KnowledgeCard beginner={beginner}/>
          <QuizCard beginner={beginner}/>
        </div>
      </main>

      <SurveyModal
        open={surveyOpen}
        onClose={() => setSurveyOpen(false)}
        onComplete={() => setHasResult(true)}
      />

      <Tour active={tourActive} step={tourStep} onNext={nextTour} onSkip={skipTour}/>
    </div>
  );
};

ReactDOM.createRoot(document.getElementById('root')).render(<App/>);
